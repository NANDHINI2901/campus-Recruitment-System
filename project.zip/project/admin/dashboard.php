<?php
require_once '../includes/db.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

// Add job
if (isset($_POST['add_job'])) {
    $company = mysqli_real_escape_string($conn, $_POST['company_name']);
    $title = mysqli_real_escape_string($conn, $_POST['job_title']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $loc = mysqli_real_escape_string($conn, $_POST['location']);
    $pkg = mysqli_real_escape_string($conn, $_POST['package']);
    $cgpa = (float)$_POST['eligibility_cgpa'];
    $date = mysqli_real_escape_string($conn, $_POST['last_date']);
    mysqli_query($conn, "INSERT INTO jobs (company_name, job_title, description, location, package, eligibility_cgpa, last_date) VALUES ('$company','$title','$desc','$loc','$pkg','$cgpa','$date')");
}
// Delete job
if (isset($_GET['delete_job'])) {
    $jid = (int)$_GET['delete_job'];
    mysqli_query($conn, "DELETE FROM applications WHERE job_id=$jid");
    mysqli_query($conn, "DELETE FROM jobs WHERE id=$jid");
}
// Update application status
if (isset($_POST['update_status'])) {
    $aid = (int)$_POST['app_id'];
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    mysqli_query($conn, "UPDATE applications SET status='$status' WHERE id=$aid");
}

// Stats
$total_students = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM students"));
$total_jobs = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM jobs"));
$total_apps = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM applications"));
$total_selected = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM applications WHERE status='selected'"));

$jobs = mysqli_query($conn, "SELECT * FROM jobs ORDER BY posted_at DESC");
$applications = mysqli_query($conn, "SELECT a.*, s.full_name, s.roll_number, s.cgpa, s.department, j.company_name, j.job_title FROM applications a JOIN students s ON a.student_id=s.id JOIN jobs j ON a.job_id=j.id ORDER BY a.applied_at DESC");
$students = mysqli_query($conn, "SELECT * FROM students ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CampusRecruit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: #f1f5f9; }
        .navbar { background: linear-gradient(135deg, #312e81, #4f46e5); padding: 14px 0; }
        .navbar-brand { font-family: 'Sora', sans-serif; font-weight: 700; color: #fff !important; }
        .stat-card { background: #fff; border-radius: 14px; padding: 22px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .stat-card .icon { font-size: 2rem; margin-bottom: 10px; }
        .stat-card h3 { font-family: 'Sora', sans-serif; font-size: 2.2rem; font-weight: 700; margin: 0; }
        .stat-card p { color: #64748b; margin: 4px 0 0; font-size: 0.88rem; }
        .section-title { font-family: 'Sora', sans-serif; font-weight: 700; color: #0f172a; }
        .nav-tabs .nav-link { color: #64748b; font-weight: 600; border: none; }
        .nav-tabs .nav-link.active { color: #4f46e5; border-bottom: 3px solid #4f46e5; background: transparent; }
        .btn-purple { background: #4f46e5; color: #fff; border: none; border-radius: 8px; padding: 10px 20px; font-weight: 600; transition: all 0.3s; }
        .btn-purple:hover { background: #3730a3; color: #fff; }
        .status-applied { background: #eff6ff; color: #1a56db; }
        .status-shortlisted { background: #fffbeb; color: #d97706; }
        .status-selected { background: #f0fdf4; color: #16a34a; }
        .status-rejected { background: #fef2f2; color: #dc2626; }
        .status-badge { padding: 3px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
        .form-control, .form-select { border-radius: 8px; border: 1.5px solid #e2e8f0; }
        .form-control:focus, .form-select:focus { border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79,70,229,0.15); }
        table th { font-weight: 700; color: #374151; background: #f8fafc; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.php"><i class="fas fa-graduation-cap me-2"></i>CampusRecruit Admin</a>
        <div class="ms-auto">
            <span class="text-white me-3"><i class="fas fa-user-shield me-1"></i><?= $_SESSION['admin_name'] ?></span>
            <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="stat-card"><div class="icon">👨‍🎓</div><h3 style="color:#1a56db"><?= $total_students ?></h3><p>Total Students</p></div></div>
        <div class="col-6 col-md-3"><div class="stat-card"><div class="icon">💼</div><h3 style="color:#4f46e5"><?= $total_jobs ?></h3><p>Job Postings</p></div></div>
        <div class="col-6 col-md-3"><div class="stat-card"><div class="icon">📋</div><h3 style="color:#f59e0b"><?= $total_apps ?></h3><p>Applications</p></div></div>
        <div class="col-6 col-md-3"><div class="stat-card"><div class="icon">🎉</div><h3 style="color:#10b981"><?= $total_selected ?></h3><p>Selected</p></div></div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4 bg-white rounded-top px-3 pt-2" style="border-bottom: 2px solid #e2e8f0;">
        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#tab-jobs">Job Postings</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-apps">Applications</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-students">Students</a></li>
    </ul>

    <div class="tab-content">
        <!-- Jobs Tab -->
        <div class="tab-pane fade show active" id="tab-jobs">
            <div class="row g-4">
                <div class="col-md-5">
                    <div class="bg-white rounded-3 p-4 shadow-sm">
                        <h5 class="section-title mb-3"><i class="fas fa-plus-circle me-2"></i>Post New Job</h5>
                        <form method="POST">
                            <div class="mb-2"><input type="text" name="company_name" class="form-control" placeholder="Company Name" required></div>
                            <div class="mb-2"><input type="text" name="job_title" class="form-control" placeholder="Job Title" required></div>
                            <div class="mb-2"><textarea name="description" class="form-control" placeholder="Job Description" rows="2"></textarea></div>
                            <div class="row g-2 mb-2">
                                <div class="col-6"><input type="text" name="location" class="form-control" placeholder="Location"></div>
                                <div class="col-6"><input type="text" name="package" class="form-control" placeholder="Package (e.g. 4 LPA)"></div>
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-6"><input type="number" step="0.01" name="eligibility_cgpa" class="form-control" placeholder="Min CGPA"></div>
                                <div class="col-6"><input type="date" name="last_date" class="form-control"></div>
                            </div>
                            <button type="submit" name="add_job" class="btn-purple w-100"><i class="fas fa-plus me-1"></i>Post Job</button>
                        </form>
                    </div>
                </div>
                <div class="col-md-7">
                    <h5 class="section-title mb-3"><i class="fas fa-list me-2"></i>All Job Postings</h5>
                    <div class="table-responsive bg-white rounded-3 shadow-sm">
                        <table class="table table-hover mb-0">
                            <thead><tr><th class="p-3">Company</th><th>Title</th><th>Package</th><th>Status</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php while ($job = mysqli_fetch_assoc($jobs)): ?>
                            <tr>
                                <td class="p-3 fw-bold"><?= htmlspecialchars($job['company_name']) ?></td>
                                <td><?= htmlspecialchars($job['job_title']) ?></td>
                                <td><?= htmlspecialchars($job['package']) ?></td>
                                <td><span class="badge bg-<?= $job['status']=='open'?'success':'secondary' ?>"><?= $job['status'] ?></span></td>
                                <td><a href="?delete_job=<?= $job['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this job?')"><i class="fas fa-trash"></i></a></td>
                            </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Applications Tab -->
        <div class="tab-pane fade" id="tab-apps">
            <h5 class="section-title mb-3"><i class="fas fa-file-alt me-2"></i>All Applications</h5>
            <div class="table-responsive bg-white rounded-3 shadow-sm">
                <table class="table table-hover mb-0">
                    <thead><tr><th class="p-3">Student</th><th>Roll No</th><th>CGPA</th><th>Company</th><th>Job</th><th>Applied</th><th>Status</th><th>Update</th></tr></thead>
                    <tbody>
                    <?php while ($app = mysqli_fetch_assoc($applications)): ?>
                    <tr>
                        <td class="p-3 fw-bold"><?= htmlspecialchars($app['full_name']) ?></td>
                        <td><?= htmlspecialchars($app['roll_number']) ?></td>
                        <td><?= $app['cgpa'] ?></td>
                        <td><?= htmlspecialchars($app['company_name']) ?></td>
                        <td><?= htmlspecialchars($app['job_title']) ?></td>
                        <td><?= date('d M', strtotime($app['applied_at'])) ?></td>
                        <td><span class="status-badge status-<?= $app['status'] ?>"><?= ucfirst($app['status']) ?></span></td>
                        <td>
                            <form method="POST" class="d-flex gap-1">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <select name="status" class="form-select form-select-sm" style="width:120px;">
                                    <option value="applied" <?= $app['status']=='applied'?'selected':'' ?>>Applied</option>
                                    <option value="shortlisted" <?= $app['status']=='shortlisted'?'selected':'' ?>>Shortlisted</option>
                                    <option value="selected" <?= $app['status']=='selected'?'selected':'' ?>>Selected</option>
                                    <option value="rejected" <?= $app['status']=='rejected'?'selected':'' ?>>Rejected</option>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-sm btn-purple"><i class="fas fa-save"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Students Tab -->
        <div class="tab-pane fade" id="tab-students">
            <h5 class="section-title mb-3"><i class="fas fa-users me-2"></i>Registered Students</h5>
            <div class="table-responsive bg-white rounded-3 shadow-sm">
                <table class="table table-hover mb-0">
                    <thead><tr><th class="p-3">Name</th><th>Roll No</th><th>Department</th><th>CGPA</th><th>Email</th><th>Phone</th><th>Registered</th></tr></thead>
                    <tbody>
                    <?php while ($s = mysqli_fetch_assoc($students)): ?>
                    <tr>
                        <td class="p-3 fw-bold"><?= htmlspecialchars($s['full_name']) ?></td>
                        <td><?= htmlspecialchars($s['roll_number']) ?></td>
                        <td><?= htmlspecialchars($s['department']) ?></td>
                        <td><?= $s['cgpa'] ?></td>
                        <td><?= htmlspecialchars($s['email']) ?></td>
                        <td><?= htmlspecialchars($s['phone'] ?: '-') ?></td>
                        <td><?= date('d M Y', strtotime($s['created_at'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
