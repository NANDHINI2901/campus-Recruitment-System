<?php
require_once '../includes/db.php';
if (isset($_SESSION['admin_id'])) { header("Location: dashboard.php"); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $pass = $_POST['password'];
    $result = mysqli_query($conn, "SELECT * FROM admins WHERE username='$username'");
    $admin = mysqli_fetch_assoc($result);
    if ($admin && $pass == 'admin123' && md5($pass) == $admin['password']) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['username'];
        header("Location: dashboard.php"); exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - CampusRecruit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: linear-gradient(135deg, #0f172a, #312e81); min-height: 100vh; display: flex; align-items: center; }
        .card { border: none; border-radius: 20px; box-shadow: 0 30px 60px rgba(0,0,0,0.3); }
        .card-header { background: linear-gradient(135deg, #312e81, #4f46e5); border-radius: 20px 20px 0 0 !important; padding: 32px; text-align: center; }
        .card-header h4 { font-family: 'Sora', sans-serif; font-weight: 700; color: #fff; margin: 0; font-size: 1.6rem; }
        .card-header p { color: rgba(255,255,255,0.8); margin: 8px 0 0; }
        .form-label { font-weight: 600; color: #374151; font-size: 0.88rem; }
        .form-control { border-radius: 8px; border: 1.5px solid #e2e8f0; padding: 12px 14px; }
        .form-control:focus { border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79,70,229,0.15); }
        .btn-login { background: linear-gradient(135deg, #312e81, #4f46e5); color: #fff; border: none; border-radius: 10px; padding: 13px; font-family: 'Sora', sans-serif; font-weight: 700; font-size: 1rem; width: 100%; transition: all 0.3s; }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(79,70,229,0.4); }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="text-center mb-4">
                <a href="../index.php" style="font-family:'Sora',sans-serif;font-weight:700;color:#fff;text-decoration:none;font-size:1.2rem;"><i class="fas fa-graduation-cap me-2"></i>CampusRecruit</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <div style="font-size:2.5rem;margin-bottom:10px;">🔐</div>
                    <h4>Admin Login</h4>
                    <p>Restricted access — admins only</p>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
                    <div class="alert alert-info small"><i class="fas fa-info-circle me-1"></i><strong>Default:</strong> username: <code>admin</code> | password: <code>admin123</code></div>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" required placeholder="admin">
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required placeholder="Password">
                        </div>
                        <button type="submit" class="btn-login"><i class="fas fa-lock-open me-2"></i>Admin Login</button>
                    </form>
                    <p class="text-center mt-3 mb-0"><a href="../index.php" class="text-muted small">← Back to Home</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
