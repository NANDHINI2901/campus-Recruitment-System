<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Recruitment System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #1a56db;
            --accent: #f59e0b;
            --dark: #0f172a;
            --light: #f8fafc;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: var(--light); }

        .hero {
            background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 60%, #1a56db 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .navbar-brand { font-family: 'Sora', sans-serif; font-weight: 700; font-size: 1.4rem; color: #fff !important; }
        .nav-link { color: rgba(255,255,255,0.8) !important; font-weight: 500; }
        .nav-link:hover { color: #fff !important; }

        .hero-content {
            flex: 1;
            display: flex;
            align-items: center;
            padding: 80px 0;
        }
        .hero h1 {
            font-family: 'Sora', sans-serif;
            font-size: 3.2rem;
            font-weight: 700;
            color: #fff;
            line-height: 1.2;
        }
        .hero h1 span { color: var(--accent); }
        .hero p { color: rgba(255,255,255,0.75); font-size: 1.1rem; margin: 1.5rem 0 2rem; }

        .btn-primary-custom {
            background: var(--accent);
            color: #0f172a;
            border: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-weight: 700;
            font-family: 'Sora', sans-serif;
            font-size: 1rem;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-primary-custom:hover { background: #fbbf24; transform: translateY(-2px); box-shadow: 0 8px 20px rgba(245,158,11,0.4); color: #0f172a; }

        .btn-outline-custom {
            background: transparent;
            color: #fff;
            border: 2px solid rgba(255,255,255,0.4);
            padding: 12px 32px;
            border-radius: 8px;
            font-weight: 600;
            font-family: 'Sora', sans-serif;
            font-size: 1rem;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
            margin-left: 12px;
        }
        .btn-outline-custom:hover { border-color: #fff; background: rgba(255,255,255,0.1); color: #fff; }

        .stats-bar {
            background: rgba(255,255,255,0.07);
            border-top: 1px solid rgba(255,255,255,0.1);
            padding: 24px 0;
        }
        .stat-item { text-align: center; }
        .stat-item h3 { font-family: 'Sora', sans-serif; font-size: 2rem; font-weight: 700; color: var(--accent); }
        .stat-item p { color: rgba(255,255,255,0.7); font-size: 0.9rem; margin: 0; }

        .features { padding: 80px 0; background: #fff; }
        .features h2 { font-family: 'Sora', sans-serif; font-size: 2.2rem; font-weight: 700; color: var(--dark); text-align: center; margin-bottom: 50px; }
        .feature-card {
            background: var(--light);
            border-radius: 16px;
            padding: 36px 28px;
            height: 100%;
            border: 1px solid #e2e8f0;
            transition: all 0.3s;
        }
        .feature-card:hover { transform: translateY(-6px); box-shadow: 0 20px 40px rgba(0,0,0,0.08); border-color: var(--primary); }
        .feature-icon {
            width: 56px; height: 56px;
            background: linear-gradient(135deg, var(--primary), #3b82f6);
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            margin-bottom: 20px;
        }
        .feature-icon i { color: #fff; font-size: 1.4rem; }
        .feature-card h5 { font-family: 'Sora', sans-serif; font-weight: 700; color: var(--dark); margin-bottom: 10px; }
        .feature-card p { color: #64748b; font-size: 0.95rem; line-height: 1.6; margin: 0; }

        footer { background: var(--dark); color: rgba(255,255,255,0.6); text-align: center; padding: 24px; font-size: 0.9rem; }
    </style>
</head>
<body>
<div class="hero">
    <nav class="navbar navbar-expand-lg px-4 pt-3">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-graduation-cap me-2"></i>CampusRecruit</a>
            <div class="ms-auto">
                <a href="student/login.php" class="nav-link d-inline me-3"><i class="fas fa-user me-1"></i>Student Login</a>
                <a href="admin/login.php" class="nav-link d-inline"><i class="fas fa-lock me-1"></i>Admin</a>
            </div>
        </div>
    </nav>

    <div class="hero-content">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <h1>Your <span>Dream Job</span><br>Starts on Campus</h1>
                    <p>A complete platform connecting students with top recruiters. Apply for jobs, track applications, and launch your career — all in one place.</p>
                    <a href="student/register.php" class="btn-primary-custom"><i class="fas fa-rocket me-2"></i>Get Started</a>
                    <a href="student/login.php" class="btn-outline-custom">Student Login</a>
                </div>
                <div class="col-lg-5 text-center d-none d-lg-block">
                    <i class="fas fa-briefcase" style="font-size: 12rem; opacity: 0.15; color:#fff;"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="stats-bar">
        <div class="container">
            <div class="row">
                <div class="col-4 stat-item"><h3>50+</h3><p>Companies</p></div>
                <div class="col-4 stat-item"><h3>200+</h3><p>Students Placed</p></div>
                <div class="col-4 stat-item"><h3>30+</h3><p>Active Jobs</p></div>
            </div>
        </div>
    </div>
</div>

<section class="features">
    <div class="container">
        <h2>Everything You Need</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-user-plus"></i></div>
                    <h5>Easy Registration</h5>
                    <p>Create your profile in minutes and start exploring opportunities right away.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-search"></i></div>
                    <h5>Browse Jobs</h5>
                    <p>Explore job postings from top companies with eligibility details and packages.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-paper-plane"></i></div>
                    <h5>One-Click Apply</h5>
                    <p>Apply to multiple companies instantly and manage all applications in one place.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-chart-line"></i></div>
                    <h5>Track Status</h5>
                    <p>Know exactly where you stand — Applied, Shortlisted, or Selected in real time.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<footer>
    <p>&copy; 2025 CampusRecruit. All rights reserved.</p>
</footer>
</body>
</html>
