<?php
require_once '../includes/db.php';
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $roll = mysqli_real_escape_string($conn, $_POST['roll_number']);
    $dept = mysqli_real_escape_string($conn, $_POST['department']);
    $cgpa = mysqli_real_escape_string($conn, $_POST['cgpa']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT id FROM students WHERE email='$email' OR roll_number='$roll'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Email or Roll Number already registered!";
    } else {
        $sql = "INSERT INTO students (full_name, email, password, roll_number, department, cgpa, phone) VALUES ('$name','$email','$pass','$roll','$dept','$cgpa','$phone')";
        if (mysqli_query($conn, $sql)) {
            $success = "Registration successful! <a href='login.php'>Login here</a>";
        } else {
            $error = "Something went wrong. Try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - CampusRecruit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: linear-gradient(135deg, #0f172a, #1e3a8a); min-height: 100vh; display: flex; align-items: center; padding: 40px 0; }
        .card { border: none; border-radius: 20px; box-shadow: 0 30px 60px rgba(0,0,0,0.3); }
        .card-header { background: linear-gradient(135deg, #1a56db, #3b82f6); border-radius: 20px 20px 0 0 !important; padding: 28px; text-align: center; }
        .card-header h4 { font-family: 'Sora', sans-serif; font-weight: 700; color: #fff; margin: 0; }
        .card-header p { color: rgba(255,255,255,0.8); margin: 5px 0 0; font-size: 0.9rem; }
        .form-label { font-weight: 600; color: #374151; font-size: 0.88rem; }
        .form-control { border-radius: 8px; border: 1.5px solid #e2e8f0; padding: 10px 14px; font-size: 0.95rem; }
        .form-control:focus { border-color: #1a56db; box-shadow: 0 0 0 3px rgba(26,86,219,0.15); }
        .btn-register { background: linear-gradient(135deg, #1a56db, #3b82f6); color: #fff; border: none; border-radius: 10px; padding: 13px; font-family: 'Sora', sans-serif; font-weight: 700; font-size: 1rem; width: 100%; transition: all 0.3s; }
        .btn-register:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(26,86,219,0.4); }
        .brand { font-family: 'Sora', sans-serif; font-weight: 700; }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-7">
            <div class="text-center mb-4">
                <a href="../index.php" class="text-white text-decoration-none brand"><i class="fas fa-graduation-cap me-2"></i>CampusRecruit</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-user-plus me-2"></i>Student Registration</h4>
                    <p>Create your account to start applying</p>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
                    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
                    <form method="POST">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="full_name" class="form-control" required placeholder="Enter full name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email Address *</label>
                                <input type="email" name="email" class="form-control" required placeholder="your@email.com">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Roll Number *</label>
                                <input type="text" name="roll_number" class="form-control" required placeholder="e.g. 21CS001">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Department *</label>
                                <select name="department" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <option>Computer Science</option>
                                    <option>Information Technology</option>
                                    <option>Electronics & Communication</option>
                                    <option>Electrical Engineering</option>
                                    <option>Mechanical Engineering</option>
                                    <option>Civil Engineering</option>
                                    <option>MBA</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">CGPA *</label>
                                <input type="number" name="cgpa" class="form-control" step="0.01" min="0" max="10" required placeholder="e.g. 8.5">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" name="phone" class="form-control" placeholder="10-digit number">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Password *</label>
                                <input type="password" name="password" class="form-control" required placeholder="Min 6 characters" minlength="6">
                            </div>
                            <div class="col-12 mt-2">
                                <button type="submit" class="btn-register"><i class="fas fa-rocket me-2"></i>Create Account</button>
                            </div>
                        </div>
                    </form>
                    <p class="text-center mt-4 mb-0 text-muted">Already have an account? <a href="login.php" class="text-primary fw-bold">Login</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
