<?php
require_once '../includes/db.php';
if (!isset($_SESSION['student_id'])) { header("Location: login.php"); exit; }
$sid = $_SESSION['student_id'];
$student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id=$sid"));

// Handle job application
if (isset($_POST['apply_job'])) {
    $jid = (int)$_POST['job_id'];
    $check = mysqli_query($conn, "SELECT id FROM applications WHERE student_id=$sid AND job_id=$jid");
    if (mysqli_num_rows($check) == 0) {
        mysqli_query($conn, "INSERT INTO applications (student_id, job_id) VALUES ($sid, $jid)");
    }
}

// Jobs
$jobs = mysqli_query($conn, "SELECT * FROM jobs WHERE status='open' ORDER BY posted_at DESC");
// Applications
$apps = mysqli_query($conn, "SELECT a.*, j.company_name, j.job_title, j.package FROM applications a JOIN jobs j ON a.job_id=j.id WHERE a.student_id=$sid ORDER BY a.applied_at DESC");
$app_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM applications WHERE student_id=$sid"));
$shortlisted = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM applications WHERE student_id=$sid AND status='shortlisted'"));
$selected = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM applications WHERE student_id=$sid AND status='selected'"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CampusRecruit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: #f1f5f9; }
        .navbar { background: linear-gradient(135deg, #0f172a, #1e3a8a); padding: 14px 0; }
        .navbar-brand { font-family: 'Sora', sans-serif; font-weight: 700; color: #fff !important; }
        .nav-link { color: rgba(255,255,255,0.8) !important; }
        .stat-card { background: #fff; border-radius: 16px; padding: 24px; border-left: 5px solid; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .stat-card.blue { border-color: #1a56db; }
        .stat-card.yellow { border-color: #f59e0b; }
        .stat-card.green { border-color: #10b981; }
        .stat-card h3 { font-family: 'Sora', sans-serif; font-size: 2rem; font-weight: 700; margin: 0; }
        .stat-card p { color: #64748b; margin: 4px 0 0; font-size: 0.9rem; }
        .section-title { font-family: 'Sora', sans-serif; font-weight: 700; color: #0f172a; margin-bottom: 20px; }
        .job-card { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); border: 1px solid #e2e8f0; transition: all 0.3s; }
        .job-card:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .job-card h5 { font-family: 'Sora', sans-serif; font-weight: 700; color: #0f172a; }
        .company-badge { background: #eff6ff; color: #1a56db; padding: 4px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 600; }
        .pkg-badge { background: #f0fdf4; color: #16a34a; padding: 4px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 600; }
        .btn-apply { background: #1a56db; color: #fff; border: none; border-radius: 8px; padding: 9px 20px; font-weight: 600; font-size: 0.9rem; transition: all 0.3s; }
        .btn-apply:hover { background: #1e40af; color: #fff; }
        .btn-applied { background: #e2e8f0; color: #94a3b8; border: none; border-radius: 8px; padding: 9px 20px; font-weight: 600; font-size: 0.9rem; cursor: not-allowed; }
        .status-applied { background: #eff6ff; color: #1a56db; }
        .status-shortlisted { background: #fffbeb; color: #d97706; }
        .status-selected { background: #f0fdf4; color: #16a34a; }
        .status-rejected { background: #fef2f2; color: #dc2626; }
        .status-badge { padding: 4px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 600; text-transform: capitalize; }
        .nav-tabs .nav-link { color: #64748b; font-weight: 600; border: none; padding: 10px 20px; }
        .nav-tabs .nav-link.active { color: #1a56db; border-bottom: 3px solid #1a56db; background: transparent; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="../index.php"><i class="fas fa-graduation-cap me-2"></i>CampusRecruit</a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <span class="text-white"><i class="fas fa-user me-1"></i><?= htmlspecialchars($student['full_name']) ?></span>
            <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="stat-card blue">
                <h3><?= $app_count ?></h3>
                <p><i class="fas fa-paper-plane me-1"></i>Total Applied</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card yellow">
                <h3><?= $shortlisted ?></h3>
                <p><i class="fas fa-star me-1"></i>Shortlisted</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card green">
                <h3><?= $selected ?></h3>
                <p><i class="fas fa-check-circle me-1"></i>Selected</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card" style="border-color:#8b5cf6;">
                <h3><?= $student['cgpa'] ?></h3>
                <p><i class="fas fa-chart-bar me-1"></i>Your CGPA</p>
            </div>
        </div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4 bg-white rounded-top px-3 pt-2" style="border-bottom: 2px solid #e2e8f0;">
        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#jobs">Browse Jobs</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#myapps">My Applications</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#profile">My Profile</a></li>
    </ul>

    <div class="tab-content">
        <!-- Jobs Tab -->
        <div class="tab-pane fade show active" id="jobs">
            <h5 class="section-title"><i class="fas fa-briefcase me-2"></i>Open Job Postings</h5>
            <div class="row g-3">
            <?php
            $applied_jobs = [];
            $app_res = mysqli_query($conn, "SELECT job_id FROM applications WHERE student_id=$sid");
            while ($row = mysqli_fetch_assoc($app_res)) $applied_jobs[] = $row['job_id'];
            mysqli_data_seek($jobs, 0);
            while ($job = mysqli_fetch_assoc($jobs)):
                $already = in_array($job['id'], $applied_jobs);
                $eligible = $student['cgpa'] >= $job['eligibility_cgpa'];
            ?>
            <div class="col-md-6">
                <div class="job-card">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="mb-0"><?= htmlspecialchars($job['job_title']) ?></h5>
                        <span class="pkg-badge"><?= htmlspecialchars($job['package']) ?></span>
                    </div>
                    <span class="company-badge mb-2 d-inline-block"><i class="fas fa-building me-1"></i><?= htmlspecialchars($job['company_name']) ?></span>
                    <p class="text-muted small mb-2"><?= htmlspecialchars($job['description']) ?></p>
                    <div class="d-flex gap-3 mb-3 text-muted small">
                        <span><i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($job['location']) ?></span>
                        <span><i class="fas fa-star me-1"></i>Min CGPA: <?= $job['eligibility_cgpa'] ?></span>
                        <span><i class="fas fa-calendar me-1"></i><?= $job['last_date'] ?></span>
                    </div>
                    <?php if ($already): ?>
                        <button class="btn-applied" disabled><i class="fas fa-check me-1"></i>Applied</button>
                    <?php elseif (!$eligible): ?>
                        <button class="btn-applied" disabled><i class="fas fa-times me-1"></i>Not Eligible</button>
                    <?php else: ?>
                        <form method="POST">
                            <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                            <button type="submit" name="apply_job" class="btn-apply"><i class="fas fa-paper-plane me-1"></i>Apply Now</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
            </div>
        </div>

        <!-- Applications Tab -->
        <div class="tab-pane fade" id="myapps">
            <h5 class="section-title"><i class="fas fa-list me-2"></i>My Applications</h5>
            <?php if (mysqli_num_rows($apps) == 0): ?>
                <div class="text-center py-5 text-muted"><i class="fas fa-inbox fa-3x mb-3 d-block"></i>No applications yet. Start applying!</div>
            <?php else: ?>
            <div class="table-responsive bg-white rounded-3 shadow-sm">
                <table class="table table-hover mb-0">
                    <thead style="background:#f8fafc;"><tr>
                        <th class="p-3">Company</th><th>Job Title</th><th>Package</th><th>Applied On</th><th>Status</th>
                    </tr></thead>
                    <tbody>
                    <?php while ($app = mysqli_fetch_assoc($apps)): ?>
                    <tr>
                        <td class="p-3 fw-bold"><?= htmlspecialchars($app['company_name']) ?></td>
                        <td><?= htmlspecialchars($app['job_title']) ?></td>
                        <td><?= htmlspecialchars($app['package']) ?></td>
                        <td><?= date('d M Y', strtotime($app['applied_at'])) ?></td>
                        <td><span class="status-badge status-<?= $app['status'] ?>"><?= ucfirst($app['status']) ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- Profile Tab -->
        <div class="tab-pane fade" id="profile">
            <h5 class="section-title"><i class="fas fa-user me-2"></i>My Profile</h5>
            <div class="bg-white rounded-3 p-4 shadow-sm" style="max-width:500px;">
                <div class="mb-3"><label class="text-muted small">Full Name</label><p class="fw-bold mb-0"><?= htmlspecialchars($student['full_name']) ?></p></div>
                <div class="mb-3"><label class="text-muted small">Email</label><p class="fw-bold mb-0"><?= htmlspecialchars($student['email']) ?></p></div>
                <div class="mb-3"><label class="text-muted small">Roll Number</label><p class="fw-bold mb-0"><?= htmlspecialchars($student['roll_number']) ?></p></div>
                <div class="mb-3"><label class="text-muted small">Department</label><p class="fw-bold mb-0"><?= htmlspecialchars($student['department']) ?></p></div>
                <div class="mb-3"><label class="text-muted small">CGPA</label><p class="fw-bold mb-0"><?= $student['cgpa'] ?></p></div>
                <div class="mb-0"><label class="text-muted small">Phone</label><p class="fw-bold mb-0"><?= htmlspecialchars($student['phone'] ?: 'Not provided') ?></p></div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
