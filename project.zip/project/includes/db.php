<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "campus_recruitment";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("<div style='font-family:sans-serif;padding:20px;color:red;'>
        <h3>Database Connection Failed</h3>
        <p>Make sure MySQL is running in XAMPP and you have imported <strong>database.sql</strong></p>
        <p>Error: " . mysqli_connect_error() . "</p>
    </div>");
}
session_start();
?>
