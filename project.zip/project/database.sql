-- Campus Recruitment System Database
CREATE DATABASE IF NOT EXISTS campus_recruitment;
USE campus_recruitment;

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    roll_number VARCHAR(50) UNIQUE NOT NULL,
    department VARCHAR(100),
    cgpa DECIMAL(4,2),
    phone VARCHAR(15),
    resume_link VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL,
    job_title VARCHAR(100) NOT NULL,
    description TEXT,
    location VARCHAR(100),
    package VARCHAR(50),
    eligibility_cgpa DECIMAL(4,2) DEFAULT 0.00,
    last_date DATE,
    posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('open','closed') DEFAULT 'open'
);

CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    job_id INT NOT NULL,
    status ENUM('applied','shortlisted','rejected','selected') DEFAULT 'applied',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (job_id) REFERENCES jobs(id),
    UNIQUE KEY unique_application (student_id, job_id)
);

-- Default admin account (username: admin, password: admin123)
INSERT INTO admins (username, password) VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Sample job postings
INSERT INTO jobs (company_name, job_title, description, location, package, eligibility_cgpa, last_date) VALUES
('TCS', 'Software Engineer', 'Develop and maintain enterprise applications.', 'Chennai', '3.5 LPA', 6.00, DATE_ADD(CURDATE(), INTERVAL 30 DAY)),
('Infosys', 'Systems Engineer', 'Work on client projects across various domains.', 'Bangalore', '3.6 LPA', 6.50, DATE_ADD(CURDATE(), INTERVAL 20 DAY)),
('Wipro', 'Project Engineer', 'Assist in building scalable software solutions.', 'Hyderabad', '3.5 LPA', 6.00, DATE_ADD(CURDATE(), INTERVAL 25 DAY));
