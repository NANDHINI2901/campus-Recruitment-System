# Campus Recruitment System - Setup Guide

## Requirements
- XAMPP (Apache + MySQL)

## Setup Steps

### Step 1 - Copy the project
Copy the `project` folder to: `C:\xampp\htdocs\project\`

### Step 2 - Import the database
1. Open XAMPP Control Panel
2. Start Apache and MySQL
3. Open browser → go to: http://localhost/phpmyadmin
4. Click "New" on the left → create database named: `campus_recruitment`
5. Click on `campus_recruitment` → go to "Import" tab
6. Click "Choose File" → select `database.sql` from this folder
7. Click "Go"

### Step 3 - Run the project
Open browser → go to: http://localhost/project/index.php

## Login Credentials

### Admin Login
- URL: http://localhost/project/admin/login.php
- Username: admin
- Password: admin123

### Student Login
- Register first at: http://localhost/project/student/register.php
- Then login with your email & password

## Features
- Student Registration & Login
- Browse open job postings
- One-click job application (with CGPA eligibility check)
- Track application status (Applied / Shortlisted / Selected / Rejected)
- Admin panel to post jobs, manage applications, and view all students
